const Auction = [
    {   id:0,
        image:"Images/Untitled-1.jpg",
        user:"active",
    },
    {
        id:1,
        image:"Images/Untitled-2.jpg",
        user:"active",
        
    },
    {
        id:2,
        image:"Images/Untitled-4.jpg",
        user:"active",
    },
    {
        id:3,
        image:"Images/Untitled-2.jpg",
        user:"active",
    },
    {
        id:4,
        image:"Images/Untitled-4.jpg",
        user:"active",
    },

    { 
        id:5,
        image:"Images/Untitled-1.jpg",
        user:"active",
    },
    
];

export default Auction;