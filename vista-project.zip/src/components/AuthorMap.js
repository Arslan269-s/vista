const AuthorMap = [
    {
         image: "Images/nfts.png",
        name: "Masniya Hug1",
        avatar: "Images/image-3.png",

    },
    {
        image: "Images/nfts.png",
        name: "Masniya Hug2",
        avatar: "Images/image-3.png",

    },
    {
         image: "Images/nfts.png",
        name: "Masniya Hug3",
        avatar: "Images/image-3.png",

    },
    {
         image: "Images/nfts.png",
        name: "Masniya Hug4",
        avatar: "Images/image-3.png",

    },
    {
         image: "Images/nfts.png",
        name: "Masniya Hug5",
        avatar: "Images/image-3.png",

    },

    {
         image: "Images/nfts.png",
        name: "Masniya Hug6",
        avatar: "Images/image-3.png",

    },
    {
         image: "Images/nfts.png",
        name: "Masniya Hug7",
        avatar: "Images/image-3.png",

    },
    {
         image: "Images/nfts.png",
        name: "Masniya Hug8",
        avatar: "Images/image-3.png",

    },
];

export default AuthorMap;