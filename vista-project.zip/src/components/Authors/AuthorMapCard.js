    const AuthorMapCard = [
            {
                 image: "Images/dummy-profile.png",
                name: "Masniya Hug1",
                avatar: "Images/image-3.png",
        
            },
            {
                image: "Images/dummy-profile.png",
                name: "Masniya Hug2",
                avatar: "Images/image-3.png",
        
            },
            {
                 image: "Images/dummy-profile.png",
                name: "Masniya Hug3",
                avatar: "Images/image-3.png",
        
            },
            {
                 image: "Images/dummy-profile.png",
                name: "Masniya Hug4",
                avatar: "Images/image-3.png",
        
            },
            {
                 image: "Images/dummy-profile.png",
                name: "Masniya Hug5",
                avatar: "Images/image-3.png",
        
            },
        
            {
                 image: "Images/dummy-profile.png",
                name: "Masniya Hug6",
                avatar: "Images/image-3.png",
        
            },
        ];
        
        export default AuthorMapCard;
  
