const BlogMap = [
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
    {
        date: "27 Aprril . Web Design",
        image: 'Images/person.jpg',
    },
];

export default BlogMap;