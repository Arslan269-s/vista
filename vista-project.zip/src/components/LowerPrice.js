const Price = [
    {
        image: "Images/image-3.png",
        text: "Dui accumsan leo vestibulam ornear uio",
        eth: "1.25 ETH",
        bidding: "101 people are bidding",
    },
    {
        image: "Images/image-4.png",
        text: "Dui accumsan leo vestibulam ornear uio",
        eth: "1.25 ETH",
        bidding: "101 people are bidding",
    },
    {
        image: "Images/image-5.png",
        text: "Dui accumsan leo vestibulam ornear uio",
        eth: "1.25 ETH",
        bidding: "101 people are bidding",
    },
    {
        image: "Images/image-6.png",
        text: "Dui accumsan leo vestibulam ornear uio",
        eth: "1.25 ETH",
        bidding: "101 people are bidding",
    },

];

export default Price;