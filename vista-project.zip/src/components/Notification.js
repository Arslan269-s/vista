import React from 'react'

export const Notification = () => {
  return (
    <div>
        <div className="notification-section padding-top padding-bottom" id="order-receive">
        <div className="container">
            <div className="notification-section-details">
                <div className='notification-close'><span>x</span></div>
            <div className="row g-5">
                <div className="col-xm-2 col-lg-2 my-2">
                <div className="notification-section-image">
                <a href="#"> <img src="assets/image/image-3.png"/></a>
                </div>
                </div>
                <div className="col-xm-10 col-lg-10 my-3">
                    <div className="notification-section-detail">
                        <a href="#"> <h5>Jhon Doe reacted to your post</h5>
                            <p className="my-0">Lorem ipsum dolor sit amet consectetur adipisicing elit.dolor sit amet consectetur adipisicing elit.</p> </a>
                            <p className="ten_mint_ago">10 min ago</p>
                    </div>
                </div>
                
            </div>
            </div>
             <div className="notification-section-details">
             <div className='notification-close'><span>x</span></div>
            <div className="row g-5">
                <div className="col-xm-2 col-lg-2 my-2">
                <div className="notification-section-image">
                <a href="#"> <img src="assets/image/image-3.png"/></a>
                </div>
                </div>
                <div className="col-xm-10 col-lg-10 my-3">
                    <div className="notification-section-detail">
                        <a href="#"> <h5>Jhon Doe reacted to your post</h5>
                            <p className="my-0">Lorem ipsum dolor sit amet consectetur adipisicing elit.dolor sit amet consectetur adipisicing elit.</p> </a>
                            <p className="ten_mint_ago">10 min ago</p>
                    </div>
                </div>
                
            </div>
            </div>
             <div className="notification-section-details">
             <div className='notification-close'><span>x</span></div>
            <div className="row g-5">
                <div className="col-xm-2 col-lg-2 my-2">
                <div className="notification-section-image">
                <a href="#"> <img src="assets/image/image-3.png"/></a>
                </div>
                </div>
                <div className="col-xm-10 col-lg-10 my-3">
                    <div className="notification-section-detail">
                        <a href="#"> <h5>Jhon Doe reacted to your post</h5>
                            <p className="my-0">Lorem ipsum dolor sit amet consectetur adipisicing elit.dolor sit amet consectetur adipisicing elit.</p> </a>
                            <p className="ten_mint_ago">10 min ago</p>
                    </div>
                </div>
                
            </div>
            </div>
             <div className="notification-section-details">
             <div className='notification-close'><span>x</span></div>
            <div className="row g-5">
                <div className="col-xm-2 col-lg-2 my-2">
                <div className="notification-section-image">
                <a href="#"> <img src="assets/image/image-3.png"/></a>
                </div>
                </div>
                <div className="col-xm-10 col-lg-10 my-3">
                    <div className="notification-section-detail">
                        <a href="#"> <h5>Jhon Doe reacted to your post</h5>
                            <p className="my-0">Lorem ipsum dolor sit amet consectetur adipisicing elit.dolor sit amet consectetur adipisicing elit.</p> </a>
                            <p className="ten_mint_ago">10 min ago</p>
                    </div>
                </div>
                
            </div>
            </div>
             <div className="notification-section-details">
             <div className='notification-close'><span>x</span></div>
            <div className="row g-5">
                <div className="col-xm-2 col-lg-2 my-2">
                <div className="notification-section-image">
                <a href="#"> <img src="assets/image/image-3.png"/></a>
                </div>
                </div>
                <div className="col-xm-10 col-lg-10 my-3">
                    <div className="notification-section-detail">
                        <a href="#"> <h5>Jhon Doe reacted to your post</h5>
                            <p className="my-0">Lorem ipsum dolor sit amet consectetur adipisicing elit.dolor sit amet consectetur adipisicing elit.</p> </a>
                            <p className="ten_mint_ago">10 min ago</p>
                    </div>
                </div>
                
            </div>
            </div>
             <div className="notification-section-details">
             <div className='notification-close'><span>x</span></div>
            <div className="row g-5">
                <div className="col-xm-2 col-lg-2 my-2">
                <div className="notification-section-image">
                <a href="#"> <img src="assets/image/image-3.png"/></a>
                </div>
                </div>
                <div className="col-xm-10 col-lg-10 my-3">
                    <div className="notification-section-detail">
                        <a href="#"> <h5>Jhon Doe reacted to your post</h5>
                            <p className="my-0">Lorem ipsum dolor sit amet consectetur adipisicing elit.dolor sit amet consectetur adipisicing elit.</p> </a>
                            <p className="ten_mint_ago">10 min ago</p>
                    </div>
                </div>
                
            </div>
            </div>
        </div>
        </div>
        </div>
    
  )
}
