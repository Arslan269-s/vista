const Rating = [
    {
       total :"300k",
       name: "User Active"
    },
    {
       total :"52,5k",
       name: "Artworks"
        
    },
    {
       total :"17,5k",
       name: "Artists"
    },
    {
       total :"35.58",
       name: "ETH Spent"
    },

];

export default Rating;