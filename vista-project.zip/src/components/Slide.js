const Slide = [
    {
        avatar1: "Images/image-3.png",
        text:'2.50 ETH',
    },
    {
        avatar1: "Images/image-6.png",
        text:'3.20 ETH',
    },
    {
        avatar1: "Images/image-5.png",
        text:'4.10 ETH',
    },
    {
        avatar1: "Images/image-6.png",
        text:'1.50 ETH',
    },
    {
        avatar1: "Images/image-5.png",
        text:'25.0 ETH',
    },
    {
        avatar1: "Images/image-3.png",
        text:'1.80 ETH',
    },
    {
        avatar1: "Images/image-5.png",
        text:'6.50 ETH',
    },
    {
        avatar1: "Images/image-3.png",
        text:'3.50 ETH',
    },
    {
        avatar1: "Images/image-6.png",
        text:'1.80 ETH',
    },
    {
        avatar1: "Images/image-3.png",
        text:'23.50 ETH',
    },
    {
        avatar1: "Images/image-5.png",
        text:'25.50 ETH',
    },
     {
        avatar1: "Images/image-6.png",
        text:'5.50 ETH',
    }
]

export default Slide;