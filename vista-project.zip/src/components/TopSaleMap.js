const TopSaleMap = [
    {
        name: "Masniya Hug1",
        avatar: "Images/image-3.png",
        eth:"2.65",
        item: "Items",
        total:"23"
    },
    {
        name: "Masniya Hug2",
        avatar: "Images/image-3.png",
        eth:"2.65",
        item: "Items",
        total: "23 "
    },
    {
        name: "Masniya Hug5",
        avatar: "Images/image-3.png",
        eth:"2.65",
        item: "Items",
        total:"113"
    },

    {
        name: "Masniya Hug6",
        avatar: "Images/image-3.png",
        eth:"2.65",
        item: "Items",
        total:"53"
    },
    {
        name: "Jamees unny",
        avatar: "Images/image-3.png",
        eth:"2.65",
        item: "Items",
        total:"21"

    },
    {
        name: "Buri maa",
        avatar: "Images/image-3.png",
        eth:"2.65",
        item: "Items",
        total:"31"
    },
];

export default TopSaleMap;