const TransactionList = [
    {
        name: 'End of the World',
        serialno: 'Serial No',
        serialnoid: 'PSNHDTRJAL1000053',
        image: "Images/Untitled-4.jpg",
        confirmed: 'Confirmed-15 days ago',
        previous: 'Previous Owner:',
        virtua: 'Virtua',
        refNo: 'Ref No. TV105550',
        price: '$60.00',
    
    },
    {
        name: 'End of the World',
        serialno: 'Serial No',
        serialnoid: 'PSNHDTRJAL1000053',
        image: "Images/Untitled-4.jpg",
        confirmed: 'Confirmed-15 days ago',
        previous: 'Previous Owner:',
        virtua: 'Virtua',
        refNo: 'Ref No. TV105550',
        price: '$60.00',
    
    },
    
];

export default TransactionList;


