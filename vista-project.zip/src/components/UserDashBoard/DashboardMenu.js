const DashboardMenu = [
    {
        eth: "3.19 ETH",
        timer: "2:41 mint left",
        image: "Images/Untitled-4.jpg",
        wishlist: "120",
        avatar1: "Images/image-3.png",
        avatar2: "Images/image-4.png",
        avatar3: "Images/image-5.png",
        avatar4: "Images/image-6.png",
    },
    {
        eth: "1.11 ETH",
         timer: "3:11 mint left",
        image : "Images/Untitled-1.jpg",
        wishlist: "570",
        avatar1: "Images/image-3.png",
        avatar2: "Images/image-4.png",
        avatar3: "Images/image-6.png",
        avatar4: "Images/image-5.png",
    },
    {
        eth: "1.63 ETH",
        timer: "3:12 mint left",
        image: "Images/Untitled-2.jpg",
        wishlist: "98",
        avatar1: "Images/image-3.png",
        avatar2: "Images/image-5.png",
        avatar3: "Images/image-6.png",
        avatar4: "Images/image-4.png",
    },
      
    
];

export default DashboardMenu;


