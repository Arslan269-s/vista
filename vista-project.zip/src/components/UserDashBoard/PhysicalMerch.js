import React from 'react'

export const PhysicalMerch = () => {
  return (
    <div className='physical-merch d-flex justify-content-between align-items-center'>
        <h4>Physical Merch</h4>
        <button className='btn-collection'>Authenticate</button>
    </div>
  )
}
